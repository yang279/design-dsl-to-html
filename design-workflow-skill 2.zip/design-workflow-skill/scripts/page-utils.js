/**
 * 获取页面完整渲染尺寸（宽+高），兼容 position:absolute 溢出父框的情况
 * 用途：Step 1 扩展视口前获取真实页面宽高，确保截图不被截断
 * 返回：{ pageWidth, pageHeight }
 * 调用方式：evaluate_script → function getPageFullSize() { ... }
 */
function getPageFullSize() {
  // scrollHeight/scrollWidth 不统计 position:absolute 溢出元素，需遍历所有节点取最大值
  let maxBottom = Math.max(
    document.body.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.scrollHeight,
    document.documentElement.offsetHeight
  );
  let maxRight = Math.max(
    document.body.scrollWidth,
    document.body.offsetWidth,
    document.documentElement.scrollWidth,
    document.documentElement.offsetWidth
  );
  document.querySelectorAll('*').forEach(el => {
    const r = el.getBoundingClientRect();
    const b = r.top  + window.scrollY + r.height;
    const e = r.left + window.scrollX + r.width;
    if (b > maxBottom) maxBottom = b;
    if (e > maxRight)  maxRight  = e;
  });
  return { pageWidth: Math.ceil(maxRight), pageHeight: Math.ceil(maxBottom) };
}

/**
 * 【截图专用】将所有 overflow:auto/scroll 容器改为 visible，让内容撑开文档高度
 * 保留 overflow:hidden（视觉裁剪效果不变）
 * 截图方式：take_screenshot fullPage:true（视口高度受屏幕限制，不能依赖 resize_page + fullPage:false）
 * 返回展开后 { scrollW, scrollH }
 */
function expandForScreenshot() {
  // 释放 html/body 的 height:100% 约束，让内容高度决定文档高度
  document.documentElement.style.height = 'auto';
  document.documentElement.style.minHeight = '0';
  document.body.style.height = 'auto';
  document.body.style.minHeight = '0';

  // 对每个 overflow:auto/scroll 容器：改为 visible，并把 height 改为 auto
  // 同时向下传播一级：直接子元素若是 height:100%，也改为 auto
  document.querySelectorAll('*').forEach(el => {
    const cs = window.getComputedStyle(el);
    const isScrollX = cs.overflowX === 'auto' || cs.overflowX === 'scroll';
    const isScrollY = cs.overflowY === 'auto' || cs.overflowY === 'scroll';
    if (!isScrollX && !isScrollY) return;

    if (isScrollX) el.style.overflowX = 'visible';
    if (isScrollY) el.style.overflowY = 'visible';
    el.style.height = 'auto';
    el.style.minHeight = '0';

    for (const child of el.children) {
      const ccs = window.getComputedStyle(child);
      if (ccs.height.endsWith('%')) {
        child.style.height = 'auto';
        child.style.minHeight = '0';
      }
    }
  });

  return { scrollW: document.documentElement.scrollWidth, scrollH: document.documentElement.scrollHeight };
}

/**
 * 【节点提取专用】展开所有溢出容器，使节点坐标覆盖全部隐藏内容
 * 用途：在截图完成后调用，解除所有 overflow 约束，使 extractNodes 能采集到
 *       overflow:hidden/auto/scroll 容器内被裁剪的子节点坐标和样式
 * 返回：展开后真实 { totalWidth, totalHeight }
 * 调用方式：evaluate_script → function expandForExtract() { ... }
 */
function expandForExtract() {
  document.querySelectorAll('*').forEach(el => {
    const hasV = el.scrollHeight > el.clientHeight + 2;
    const hasH = el.scrollWidth  > el.clientWidth  + 2;
    if (!hasV && !hasH) return;
    el.style.overflow = 'visible';
    if (hasV) el.style.minHeight = el.scrollHeight + 'px';
    if (hasH) el.style.minWidth  = el.scrollWidth  + 'px';
  });
  let maxRight = 0, maxBottom = 0;
  document.querySelectorAll('*').forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.left + r.width  > maxRight)  maxRight  = r.left + r.width;
    if (r.top  + r.height > maxBottom) maxBottom = r.top  + r.height;
  });
  maxRight = Math.ceil(maxRight); maxBottom = Math.ceil(maxBottom);
  document.documentElement.style.minHeight = maxBottom + 'px';
  document.documentElement.style.minWidth  = maxRight  + 'px';
  document.body.style.minHeight = maxBottom + 'px';
  document.body.style.minWidth  = maxRight  + 'px';
  return { totalWidth: document.documentElement.scrollWidth, totalHeight: document.documentElement.scrollHeight };
}

/**
 * 检查页面内所有 <img> 是否已加载完成
 * 用途：Step 1 扩展视口触发懒加载后，等待图片就绪再截图
 * 返回：{ total, loaded, allLoaded }
 * 调用方式：evaluate_script → function checkImagesLoaded() { ... }
 */
function checkImagesLoaded() {
  const imgs  = [...document.querySelectorAll('img')];
  const total  = imgs.length;
  const loaded = imgs.filter(img => img.complete && img.naturalWidth > 0).length;
  return { total, loaded, allLoaded: total === 0 || loaded === total };
}
